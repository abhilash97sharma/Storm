package com.Storm1;

import java.util.Map;

import org.apache.storm.spout.SpoutOutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichSpout;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Values;

public class MySpout1 extends BaseRichSpout{

	SpoutOutputCollector spoutoutputcollector;
	private Integer index =0;
	
	public void open(Map conf, TopologyContext context, SpoutOutputCollector collector) {
		// TODO Auto-generated method stub
		this.spoutoutputcollector=collector;
	}

	public void nextTuple() {
		// TODO Auto-generated method stub
		if(index < 100) {
			System.out.println("In the spout block:"+index);
			this.spoutoutputcollector.emit(new Values(index));
	//		this.spoutoutputcollector.emit("Stream1",new Values(index)); //this is try.
			index++;
			}
	//	String s2="Abhilash";  //this is try
	//	this.spoutoutputcollector.emit("Stream2",new Values(s2));  //this is try.
	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		// TODO Auto-generated method stub
		declarer.declare(new Fields("First"));
	//	declarer.declareStream("Stream1", new Fields("First"));  //this is try.
	//	declarer.declareStream("Stream2", new Fields("Second")); //this is try.
	}

}
