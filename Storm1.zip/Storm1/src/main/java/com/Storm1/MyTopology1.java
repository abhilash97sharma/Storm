package com.Storm1;

import org.apache.storm.topology.*;
import org.apache.storm.tuple.Fields;
import org.apache.storm.Config;
import org.apache.storm.LocalCluster;

public class MyTopology1 {
  public static void main(String[]args) {
	  TopologyBuilder builder = new TopologyBuilder();
	  builder.setSpout("Spout", new MySpout1());
	  builder.setBolt("Bolt1", new MyBolt1()).fieldsGrouping("Spout", new Fields("First"));
	  builder.setBolt("Bolt2", new MyBolt2()).fieldsGrouping("Bolt1", new Fields("firstfield1"));
//	  builder.setBolt("Bolt2",new MyBolt2()).fieldsGrouping("Spout", new Fields("Second")); //this is try.
//	  builder.setBolt("Bolt", new MyBolt1()).shuffleGrouping("Spout");
//	  builder.setBolt("bolt2",new MyBolt2()).shuffleGrouping("Bolt");
	
	  Config config=new Config();
	  config.setDebug(true);
	  LocalCluster cluster = new LocalCluster();
	  
	  try {
	  cluster.submitTopology("FirstTopology", config ,builder.createTopology());
	  try {
		Thread.sleep(100000);
	    } catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	    }
	  }
	  finally {
		  cluster.shutdown();
	  }
  }
}

