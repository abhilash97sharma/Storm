package com.Storm1;

import org.apache.storm.topology.BasicOutputCollector;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseBasicBolt;
import org.apache.storm.tuple.Tuple;

public class MyBolt2 extends BaseBasicBolt{

	public void execute(Tuple input, BasicOutputCollector collector) {
		// TODO Auto-generated method stub
		int index1=input.getInteger(0);
        index1++;
	//	String index1=input.getStringByField("Second"); //this is try
    //    collector.emit(new Values(index1));
  /*      RecordFormat format = new DelimitedRecordFormat().withFieldDelimiter("|");

      //Synchronize data buffer with the filesystem every 1000 tuples
      SyncPolicy syncPolicy = new CountSyncPolicy(1000);

      // Rotate data files when they reach five MB
      FileRotationPolicy rotationPolicy = new FileSizeRotationPolicy(5.0f, Units.MB);

      // Use default, Storm-generated file names
      FileNameFormat fileNameFormat = new DefaultFileNameFormat().withPath("/foo");

      // Instantiate the HdfsBolt
      HdfsBolt bolt = new HdfsBolt()
           .withFsURL("hdfs://localhost:9000")
           .withFileNameFormat(fileNameFormat)
           .withRecordFormat(format)
           .withRotationPolicy(rotationPolicy)
           .withSyncPolicy(syncPolicy);*/
	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		// TODO Auto-generated method stub
	
	}

}
