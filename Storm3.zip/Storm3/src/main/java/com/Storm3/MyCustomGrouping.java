package com.Storm3;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.storm.generated.GlobalStreamId;
import org.apache.storm.grouping.CustomStreamGrouping;
import org.apache.storm.task.WorkerTopologyContext;

public class MyCustomGrouping implements CustomStreamGrouping, Serializable{

	int numTasks = 0;
	
 public void prepare(WorkerTopologyContext context, GlobalStreamId stream, List<Integer> targetTasks) {
	// TODO Auto-generated method stub
	 numTasks = targetTasks.size();
	
 }

 public List<Integer> chooseTasks(int taskId, List<Object> values) {
	// TODO Auto-generated method stub
	 List<Integer> boltIds = new ArrayList();
     if(values.size()>0){
         String str = values.get(0).toString();
         System.out.println("This is numTask:"+numTasks);
         System.out.println("This is chooseTask:"+str);
         if(str.isEmpty())
             boltIds.add(0);
         else
             boltIds.add(str.charAt(3) % numTasks);
     }
     System.out.println("This is boltIDS"+boltIds);
     return boltIds;
 }
}