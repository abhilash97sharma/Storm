package com.Storm3;

import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.apache.storm.topology.TopologyBuilder;

public class MyTopology1 {
	public static void main(String []args) {
	 TopologyBuilder builder=new TopologyBuilder();
	 builder.setSpout("spout1", new MySpout1());
	 builder.setBolt("bolt1", new MyBolt1()).customGrouping("spout1", new MyCustomGrouping());
	 builder.setBolt("bolt2", new MyBolt2()).customGrouping("spout1", new MyCustomGrouping());
	 Config config=new Config();
	 config.setDebug(true);
	 LocalCluster cluster = new LocalCluster();
	  
	  try {
	  cluster.submitTopology("FirstTopology", config ,builder.createTopology());
	  }
	  finally {
	//	  cluster.shutdown();
	  }
	}
}
