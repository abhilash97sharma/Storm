package com.Storm2;

import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.tuple.Fields;

public class MyTopology2 {
	public static void main(String[]args) {
		  TopologyBuilder builder = new TopologyBuilder();
		  builder.setSpout("Spout2", new MySpout2());
//		  builder.setBolt("Bolt1", new MyBolt2()).fieldsGrouping("Spout2", new Fields("First"));
//		  builder.setBolt("Bolt2",new MyBolt2()).fieldsGrouping("Spout", new Fields("Second")); //this is try.
//		  builder.setBolt("Bolt", new MyBolt1()).shuffleGrouping("Spout");
		  builder.setBolt("bolt2",new MyBolt2()).shuffleGrouping("Spout2");
//		  builder.setBolt("bolt3", new MyBolt3()).fieldsGrouping("bolt2", new Fields("ID1"));
//		  builder.setBolt("bolt3", new MyBolt3()).shuffleGrouping("bolt2");
		
		  Config config=new Config();
		  config.setDebug(true);
		  LocalCluster cluster = new LocalCluster();
		  
		  try {
		  cluster.submitTopology("FirstTopology", config ,builder.createTopology());
		  try {
			Thread.sleep(10000000);
		    } catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		    }
		  }
		  finally {
		//	  cluster.shutdown();
		  }
	  }
}
