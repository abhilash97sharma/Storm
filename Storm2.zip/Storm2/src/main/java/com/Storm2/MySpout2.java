package com.Storm2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Map;

import org.apache.storm.spout.SpoutOutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichSpout;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Values;

public class MySpout2 extends BaseRichSpout{

	SpoutOutputCollector spoutoutputcollector;
	public void open(Map conf, TopologyContext context, SpoutOutputCollector collector) {
		// TODO Auto-generated method stub
		this.spoutoutputcollector=collector;
	}

	public void nextTuple() {
		// TODO Auto-generated method stub
		 try {
				FileReader file1=new FileReader("/home/abhilash/Documents/files/Sample");
				BufferedReader br = new BufferedReader(file1);
				String str="";
				while((str=br.readLine())!=null) {
				//	System.out.println(str.toString());
					String []s1=str.split("\t");
					this.spoutoutputcollector.emit(new Values(s1[0],s1[1],s1[2]));
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		// TODO Auto-generated method stub
		declarer.declare(new Fields("ID","Name","Sal"));
	}

}
