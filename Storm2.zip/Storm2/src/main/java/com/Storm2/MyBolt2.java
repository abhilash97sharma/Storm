package com.Storm2;

import org.apache.storm.topology.BasicOutputCollector;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseBasicBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;

public class MyBolt2 extends BaseBasicBolt{

	public void execute(Tuple input, BasicOutputCollector collector) {
		// TODO Auto-generated method stub
	//	String s1=input.getString(1);  //getting elements by index
		String id=input.getStringByField("ID");
		String name=input.getStringByField("Name");
		String sal =input.getStringByField("Sal");
		System.out.println(id);
		System.out.println(name);
		System.out.println(sal);
		collector.emit(new Values(id));
	//	collector.emit(new Values(name));
	//	collector.emit(new Values(sal));
	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		// TODO Auto-generated method stub
		declarer.declare(new Fields("ID1","Name1","Sal1"));
	}

}
